// Include images
let img_src = [
  	'https://biohackingcore.com/wp-content/uploads/2021/09/Untitled-design-16y.png',
	'https://biohackingcore.com/wp-content/uploads/2021/09/Untitled-design-19.png',
	'https://biohackingcore.com/wp-content/uploads/2021/09/Untitled-design-23y.png'
];

// Name images included
let image_type = img_src.map(function(cuurentEl, index){ return "image" + index});
